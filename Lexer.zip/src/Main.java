import java.io.*;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        Lexer.Token token;
        Lexer lexer = new Lexer();
        token = lexer.getToken();
        while (token.tipo != Lexer.TOKEN_TYPES.EOF) {
            if (token.tipo == Lexer.TOKEN_TYPES.TK_ERROR) {
                System.out.println(">>> Error lexico(linea:" + token.linea + ",posicion:" + token.posicion + ")");
                break;
            }
            System.out.println(token);
            token = lexer.getToken();
        }
    }
}
